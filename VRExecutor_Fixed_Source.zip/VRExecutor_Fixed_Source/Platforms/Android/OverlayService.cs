
using Android.App;
using Android.Content;
using Android.Graphics;
using Android.Graphics.Drawables;
using Android.OS;
using Android.Views;
using Android.Widget;
using AndroidX.Core.App;

using AColor = Android.Graphics.Color;
using AView = Android.Views.View;
using AButton = Android.Widget.Button;

namespace VRExecutor;

[Service(
    Enabled = true,
    Exported = false,
    ForegroundServiceType = Android.Content.PM.ForegroundService.TypeSpecialUse)]
public class OverlayService : Service
{
    const string ChannelId = "vr_overlay_channel";
    const int NotificationId = 4102;

    IWindowManager? _windowManager;
    LinearLayout? _overlayView;
    WindowManagerLayoutParams? _layoutParams;
    bool _viewAdded;

    float _downRawX, _downRawY;
    int _startX, _startY;

    public override IBinder? OnBind(Intent? intent) => null;

    public override void OnCreate()
    {
        base.OnCreate();

        try
        {
            CreateNotificationChannel();

            var notification = new NotificationCompat.Builder(this, ChannelId)
                .SetContentTitle("VR Executor")
                .SetContentText("VR overlay is active")
                .SetSmallIcon(Android.Resource.Drawable.IcDialogInfo)
                .SetOngoing(true)
                .SetPriority((int)NotificationPriority.Low)
                .Build();

            if (Build.VERSION.SdkInt >= BuildVersionCodes.UpsideDownCake)
            {
                StartForeground(
                    NotificationId,
                    notification,
                    Android.Content.PM.ForegroundService.TypeSpecialUse);
            }
            else
            {
                StartForeground(NotificationId, notification);
            }

            _windowManager =
                (IWindowManager)GetSystemService(WindowService)!;

            BuildOverlay();

            if (_overlayView != null && _layoutParams != null)
            {
                _windowManager.AddView(_overlayView, _layoutParams);
                _viewAdded = true;
            }
        }
        catch (Exception ex)
        {
            Toast.MakeText(
                this,
                "Overlay error: " + ex.Message,
                ToastLength.Long)?.Show();

            StopSelf();
        }
    }

    void BuildOverlay()
    {
        var overlayType = Build.VERSION.SdkInt >= BuildVersionCodes.O
            ? WindowManagerTypes.ApplicationOverlay
            : WindowManagerTypes.Phone;

        _layoutParams = new WindowManagerLayoutParams(
            WindowManagerLayoutParams.WrapContent,
            WindowManagerLayoutParams.WrapContent,
            overlayType,
            WindowManagerFlags.NotTouchModal |
            WindowManagerFlags.LayoutInScreen,
            Format.Translucent)
        {
            Gravity = GravityFlags.Top | GravityFlags.Left,
            X = 80,
            Y = 100
        };

        _overlayView = new LinearLayout(this)
        {
            Orientation = Orientation.Vertical,
            Background = Bubble(AColor.Rgb(255, 230, 240), 28)
        };

        _overlayView.SetPadding(24, 20, 24, 20);
        _overlayView.Elevation = 12f;

        var header = new TextView(this)
        {
            Text = "VR Executor  •  drag to move",
            TextSize = 18,
            Gravity = GravityFlags.Center,
            Typeface = Typeface.Create(
                "sans-serif-medium",
                TypefaceStyle.Bold)
        };

        header.SetTextColor(AColor.Rgb(75, 115, 210));
        header.SetPadding(8, 8, 8, 16);
        header.SetOnTouchListener(new DragTouchListener(this));

        _overlayView.AddView(header);

        var editor = new EditText(this)
        {
            Hint = "Enter text...",
            Gravity = GravityFlags.Top | GravityFlags.Left,
            Background = Bubble(AColor.White, 15),
            InputType =
                Android.Text.InputTypes.ClassText |
                Android.Text.InputTypes.TextFlagMultiLine |
                Android.Text.InputTypes.TextFlagCapSentences
        };

        editor.SetMinLines(4);
        editor.SetMaxLines(7);
        editor.SetPadding(16, 14, 16, 14);
        editor.SetTextColor(AColor.DarkGray);
        editor.SetHintTextColor(AColor.LightGray);

        _overlayView.AddView(
            editor,
            new LinearLayout.LayoutParams(
                300,
                ViewGroup.LayoutParams.WrapContent));

        var buttons = new LinearLayout(this)
        {
            Orientation = Orientation.Horizontal
        };

        buttons.SetGravity(GravityFlags.Center);
        buttons.SetPadding(0, 16, 0, 0);

        var close = new AButton(this)
        {
            Text = "Close"
        };

        close.Click += (s, e) => StopSelf();

        buttons.AddView(
            close,
            new LinearLayout.LayoutParams(
                0,
                ViewGroup.LayoutParams.WrapContent,
                1));

        var status = new TextView(this)
        {
            Text = "Overlay ready",
            TextSize = 12
        };

        status.Gravity = GravityFlags.Center;
        status.SetTextColor(AColor.Rgb(80, 80, 100));

        _overlayView.AddView(buttons);
        _overlayView.AddView(status);
    }

    GradientDrawable Bubble(AColor color, float radius)
    {
        var drawable = new GradientDrawable();

        drawable.SetShape(ShapeType.Rectangle);
        drawable.SetCornerRadius(radius);
        drawable.SetColor(color);
        drawable.SetStroke(2, AColor.Rgb(235, 190, 215));

        return drawable;
    }

    sealed class DragTouchListener :
        Java.Lang.Object,
        AView.IOnTouchListener
    {
        readonly OverlayService _service;

        public DragTouchListener(OverlayService service)
        {
            _service = service;
        }

        public bool OnTouch(AView? view, MotionEvent? e)
        {
            if (e == null ||
                _service._layoutParams == null ||
                !_service._viewAdded)
                return false;

            switch (e.Action)
            {
                case MotionEventActions.Down:
                    _service._downRawX = e.RawX;
                    _service._downRawY = e.RawY;

                    _service._startX = _service._layoutParams.X;
                    _service._startY = _service._layoutParams.Y;

                    return true;

                case MotionEventActions.Move:
                    _service._layoutParams.X =
                        _service._startX +
                        (int)(e.RawX - _service._downRawX);

                    _service._layoutParams.Y =
                        _service._startY +
                        (int)(e.RawY - _service._downRawY);

                    try
                    {
                        if (_service._windowManager != null &&
                            _service._overlayView != null)
                        {
                            _service._windowManager.UpdateViewLayout(
                                _service._overlayView,
                                _service._layoutParams);
                        }
                    }
                    catch (Java.Lang.IllegalArgumentException)
                    {
                    }

                    return true;

                case MotionEventActions.Up:
                case MotionEventActions.Cancel:
                    return true;
            }

            return false;
        }
    }

    void CreateNotificationChannel()
    {
        if (Build.VERSION.SdkInt < BuildVersionCodes.O)
            return;

        var channel = new NotificationChannel(
            ChannelId,
            "VR Overlay",
            NotificationImportance.Low)
        {
            Description = "Keeps the VR overlay service running."
        };

        var manager =
            (NotificationManager?)GetSystemService(NotificationService);

        manager?.CreateNotificationChannel(channel);
    }

    public override void OnDestroy()
    {
        if (_viewAdded && _overlayView != null)
        {
            try
            {
                _windowManager?.RemoveView(_overlayView);
            }
            catch (Java.Lang.IllegalArgumentException)
            {
            }

            _viewAdded = false;
        }

        base.OnDestroy();
    }
}
