# VR Executor – compatibility repair

Changes made:
- Fixed dragging so only the title bar captures touch. The previous whole-panel touch listener consumed taps and prevented the editor/buttons from working.
- Kept the overlay focusable so the text field can open the keyboard.
- Added Android 14+ `specialUse` foreground-service declaration and permission required for this persistent overlay service.
- Added notification channel/ongoing notification and safer service cleanup.
- Added overlay-permission return handling and guarded service startup.
- Added the missing MAUI app bootstrap files (`MauiProgram.cs` and `App.cs`) that were absent from the supplied ZIP.
- Set Android target SDK 35 and minimum Android API 23.

Important:
- This is a floating VR text panel only. The Inject/Execute controls from the original were placeholder toast buttons; this repair does not add injection or execution functionality.
- Android/Quest firmware and vendor policies can still restrict overlays in some VR environments.
- The uploaded ZIP did not contain a .NET SDK/MAUI build setup. An APK could not be compiled in this environment. Open this project with .NET 8 MAUI Android workload installed, then build for Android.
- If the generated manifest reports a duplicate `OverlayService` entry, remove the explicit `<service>` element and retain the `[Service(...)]` attribute; the .NET Android build system generates the service entry from that attribute. Keep the two `<uses-permission>` declarations and the special-use subtype metadata on the generated service entry.
