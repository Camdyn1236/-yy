using Microsoft.Maui.Controls;
using Microsoft.Maui.Graphics;

namespace VRExecutor;

public class App : Application
{
    public App()
    {
        var editor = new Editor
        {
            Placeholder = "Enter script or code...",
            TextColor = Color.FromArgb("#505064"),
            PlaceholderColor = Colors.Gray,
            BackgroundColor = Colors.White,
            MinimumHeightRequest = 150,
            MaximumHeightRequest = 250,
            AutoSize = EditorAutoSizeOption.TextChanges
        };

        var status = new Label
        {
            Text = "Ready",
            FontSize = 13,
            TextColor = Color.FromArgb("#505064"),
            HorizontalOptions = LayoutOptions.Center
        };

        var inject = new Button
        {
            Text = "Inject",
            BackgroundColor = Color.FromArgb("#4B73D2"),
            TextColor = Colors.White,
            CornerRadius = 14,
            FontAttributes = FontAttributes.Bold
        };

        var execute = new Button
        {
            Text = "Execute",
            BackgroundColor = Color.FromArgb("#D85B91"),
            TextColor = Colors.White,
            CornerRadius = 14,
            FontAttributes = FontAttributes.Bold
        };

        var clear = new Button
        {
            Text = "Clear",
            BackgroundColor = Color.FromArgb("#777777"),
            TextColor = Colors.White,
            CornerRadius = 14
        };

        var close = new Button
        {
            Text = "Close",
            BackgroundColor = Color.FromArgb("#333344"),
            TextColor = Colors.White,
            CornerRadius = 14
        };

        inject.Clicked += (sender, args) =>
        {
            status.Text = "No injection backend configured.";
        };

        execute.Clicked += (sender, args) =>
        {
            if (string.IsNullOrWhiteSpace(editor.Text))
            {
                status.Text = "Enter some code first.";
                return;
            }

            status.Text = "No execution backend configured.";
        };

        clear.Clicked += (sender, args) =>
        {
            editor.Text = "";
            status.Text = "Editor cleared.";
        };

        close.Clicked += (sender, args) =>
        {
#if ANDROID
            Microsoft.Maui.ApplicationModel.Platform.CurrentActivity?.Finish();
#endif
        };

        var panel = new Border
        {
            BackgroundColor = Color.FromArgb("#FFE6F0"),
            Stroke = Color.FromArgb("#EBBED7"),
            StrokeThickness = 2,
            Padding = 24,

            StrokeShape =
                new Microsoft.Maui.Controls.Shapes.RoundRectangle
                {
                    CornerRadius = 28
                },

            WidthRequest = 460,
            HorizontalOptions = LayoutOptions.Center,
            VerticalOptions = LayoutOptions.Center,

            Content = new VerticalStackLayout
            {
                Spacing = 15,

                Children =
                {
                    new Label
                    {
                        Text = "VR Executor",
                        FontSize = 25,
                        FontAttributes = FontAttributes.Bold,
                        TextColor = Color.FromArgb("#4B73D2"),
                        HorizontalOptions = LayoutOptions.Center
                    },

                    editor,

                    inject,
                    execute,

                    new HorizontalStackLayout
                    {
                        Spacing = 10,
                        Children =
                        {
                            clear,
                            close
                        }
                    },

                    status
                }
            }
        };

        MainPage = new ContentPage
        {
            BackgroundColor = Color.FromArgb("#17131D"),

            Content = new Grid
            {
                Padding = 24,
                Children = { panel }
            }
        };
    }
}